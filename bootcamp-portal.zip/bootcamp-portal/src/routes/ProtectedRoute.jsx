import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/**
 * Gates a route by role. This is a UX convenience only — the real
 * enforcement happens server-side in /api/board-data (see server/api),
 * which independently checks the session's role before returning data.
 * Never rely on this component alone to protect sensitive data.
 */
export default function ProtectedRoute({ allow, children }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;
  if (!allow.includes(user.role)) {
    // Bounce to the dashboard that actually matches their role
    return <Navigate to={user.role === "board" ? "/dashboard/board" : "/dashboard/member"} replace />;
  }
  return children;
}
