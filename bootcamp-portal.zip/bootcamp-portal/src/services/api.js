/**
 * Frontend data layer. Every call here hits OUR backend (server/api/*),
 * which is the only layer that ever holds NOTION_API_KEY. The browser
 * never talks to api.notion.com directly — see README §3.
 */

const BASE = import.meta.env.VITE_API_BASE_URL || "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    credentials: "include", // send the session cookie; the server derives identity from it
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    throw new Error(`API ${path} failed: ${res.status}`);
  }
  return res.json();
}

// Server resolves the member from the session — no memberId is sent from the client.
export function fetchMemberData() {
  return request("/member-data");
}

// Server checks for an admin/board role claim before returning aggregates.
export function fetchBoardData() {
  return request("/board-data");
}
