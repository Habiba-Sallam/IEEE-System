import { Link } from "react-router-dom";
import Sidebar from "../components/shared/Sidebar";
import Topbar from "../components/shared/Topbar";
import SubmissionFormEmbed from "../components/member/SubmissionFormEmbed";

export default function TaskSubmissionPage() {
  return (
    <div className="layout">
      <Sidebar />
      <div className="main-col">
        <Topbar title="Submit Task" subtitle="Upload your work before the deadline" />
        <div className="content" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Link to="/dashboard/member" style={{ color: "var(--royal-light)", fontSize: 13, textDecoration: "none" }}>
            ← Back to dashboard
          </Link>
          <SubmissionFormEmbed />
        </div>
      </div>
    </div>
  );
}
