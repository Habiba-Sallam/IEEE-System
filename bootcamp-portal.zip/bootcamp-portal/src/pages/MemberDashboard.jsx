import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/shared/Sidebar";
import Topbar from "../components/shared/Topbar";
import TrackBanner from "../components/member/TrackBanner";
import DeadlineList from "../components/member/DeadlineList";
import TaskCompletionDonut from "../components/member/TaskCompletionDonut";
import ScoresBarChart from "../components/member/ScoresBarChart";
import SubmissionFormEmbed from "../components/member/SubmissionFormEmbed";
import { fetchMemberData } from "../services/api";
import useScrollToHash from "../hooks/useScrollToHash";

// Fallback so the layout is always demonstrable, even before /api/member-data is live.
const MOCK = {
  track: "AI",
  streak: 6,
  nextMilestone: "Model Evaluation — due in 4 days",
  deadlines: [
    { id: 1, title: "Task 4: Neural Net Basics", track: "AI Track", daysLeft: 1 },
    { id: 2, title: "Weekly Reflection Log", track: "AI Track", daysLeft: 3 },
    { id: 3, title: "Task 5: Model Evaluation", track: "AI Track", daysLeft: 6 },
  ],
  tasksCompleted: 7,
  tasksPending: 2,
  scores: [
    { task: "T1", score: 92 }, { task: "T2", score: 78 }, { task: "T3", score: 85 },
    { task: "T4", score: 60 }, { task: "T5", score: 88 },
  ],
};

export default function MemberDashboard() {
  const [data, setData] = useState(MOCK);
  const navigate = useNavigate();
  useScrollToHash(); // makes Sidebar links like "/dashboard/member#track" actually jump there

  useEffect(() => {
    fetchMemberData()
      .then(setData)
      .catch((err) => console.warn("[member-data] using demo data:", err.message));
  }, []);

  return (
    <div className="layout">
      <Sidebar />
      <div className="main-col">
        <Topbar title="My Dashboard" subtitle="Track your progress and stay on top of deadlines" />
        <div className="content" style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div id="track">
            <TrackBanner
              track={data.track}
              streak={data.streak}
              nextMilestone={data.nextMilestone}
              onViewRoadmap={() => navigate("/dashboard/member/tasks")}
            />
          </div>
          <DeadlineList deadlines={data.deadlines} />
          <div id="progress" className="grid-2">
            <TaskCompletionDonut completed={data.tasksCompleted} pending={data.tasksPending} />
            <ScoresBarChart scores={data.scores} />
          </div>
          <SubmissionFormEmbed />
        </div>
      </div>
    </div>
  );
}
