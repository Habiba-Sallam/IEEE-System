import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import BoardPasswordModal from "../components/shared/BoardPasswordModal";

/**
 * Placeholder login screen. Swap the two buttons for your real auth flow
 * (SSO, email/password, Notion OAuth, whatever you're using) — the only
 * contract the rest of the app needs is that `login()` ends up setting a
 * user with a `role` of "member" or "board".
 */
export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [showBoardGate, setShowBoardGate] = useState(false);

  function continueAsMember() {
    login("member");
    navigate("/dashboard/member", { replace: true });
  }

  function handleBoardUnlock() {
    setShowBoardGate(false);
    login("board");
    navigate("/dashboard/board", { replace: true });
  }

  return (
    <div
      style={{
        minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
        background: "var(--bg)", color: "var(--text)", fontFamily: "var(--font)",
      }}
    >
      <div className="panel" style={{ width: 360, textAlign: "center" }}>
        <div
          style={{
            width: 48, height: 48, borderRadius: 12, margin: "0 auto 16px",
            display: "grid", placeItems: "center",
            background: "linear-gradient(135deg, var(--royal), var(--royal-light))",
            fontWeight: 700, fontSize: 13,
          }}
        >
          IEEE
        </div>
        <h1 style={{ fontSize: 20, margin: "0 0 6px" }}>Bootcamp Portal</h1>
        <p style={{ color: "var(--text-dim)", fontSize: 13.5, margin: "0 0 24px" }}>
          Sign in to continue
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <button className="btn-primary" onClick={continueAsMember}>
            Continue as Trainee
          </button>
          <button className="btn-ghost" onClick={() => setShowBoardGate(true)}>
            Continue as Board Member
          </button>
        </div>
      </div>

      <BoardPasswordModal
        open={showBoardGate}
        onSuccess={handleBoardUnlock}
        onCancel={() => setShowBoardGate(false)}
      />
    </div>
  );
}
