import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div
      style={{
        minHeight: "100vh", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center", gap: 12,
        background: "var(--bg)", color: "var(--text)", fontFamily: "var(--font)",
      }}
    >
      <span style={{ fontSize: 48, fontWeight: 700, color: "var(--royal-light)" }}>404</span>
      <p style={{ color: "var(--text-dim)" }}>That page doesn't exist.</p>
      <Link to="/" className="btn-primary" style={{ textDecoration: "none", display: "inline-block" }}>
        Back to dashboard
      </Link>
    </div>
  );
}
