import { Link } from "react-router-dom";
import Sidebar from "../components/shared/Sidebar";
import Topbar from "../components/shared/Topbar";
import EvaluationFormEmbed from "../components/board/EvaluationFormEmbed";

export default function EvaluationsPage() {
  return (
    <div className="layout">
      <Sidebar />
      <div className="main-col">
        <Topbar title="Evaluations" subtitle="Log session evaluations and committee reports" />
        <div className="content" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Link to="/dashboard/board" style={{ color: "var(--royal-light)", fontSize: 13, textDecoration: "none" }}>
            ← Back to dashboard
          </Link>
          <EvaluationFormEmbed />
        </div>
      </div>
    </div>
  );
}
