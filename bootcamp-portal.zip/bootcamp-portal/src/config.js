/**
 * Demo-only gate for the Board Dashboard. This is a client-side speed bump,
 * NOT real security — anyone can read this constant in the shipped JS bundle.
 * Replace this with a real check against your auth backend (verify the
 * password server-side, issue a session, and have ProtectedRoute/`/api/board-data`
 * trust the session — never a client-side string match — before this goes live.
 */
export const BOARD_ACCESS_PASSWORD = "board123";
