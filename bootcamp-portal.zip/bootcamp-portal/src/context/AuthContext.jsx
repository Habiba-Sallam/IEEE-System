import { createContext, useContext, useState } from "react";

/**
 * Minimal auth context. In production, `user` is populated by your real
 * auth flow (e.g. Notion OAuth, a school SSO, or a simple email/password
 * backend) — this component only cares about the SHAPE it needs:
 *   { id, name, role: "member" | "board", track }
 *
 * The role must come from the server-issued session, never from something
 * the client can edit (e.g. never trust a `?role=board` query param).
 */
const AuthContext = createContext(null);

const DEMO_USERS = {
  member: { id: "member_123", name: "Sarah Ahmed", role: "member", track: "AI" },
  board: { id: "admin_1", name: "Karim Hossam", role: "board", track: null },
};

export function AuthProvider({ children }) {
  // Replace this with real session hydration (e.g. fetch('/api/session')).
  // Starts logged out so the routing/login flow is actually exercised.
  const [user, setUser] = useState(null);

  function login(role = "member") {
    setUser(DEMO_USERS[role] ?? DEMO_USERS.member);
  }

  function logout() {
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
