import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import BoardPasswordModal from "./BoardPasswordModal";

export default function Topbar({ title, subtitle }) {
  const { user, login, logout } = useAuth();
  const navigate = useNavigate();
  const [showBoardGate, setShowBoardGate] = useState(false);

  function handleLogout() {
    logout();
    navigate("/login", { replace: true });
  }

  function handleSwitchRole() {
    if (user.role === "board") {
      // board -> member never needs the password
      login("member");
      navigate("/dashboard/member");
    } else {
      // member -> board is gated
      setShowBoardGate(true);
    }
  }

  function handleBoardUnlock() {
    setShowBoardGate(false);
    login("board");
    navigate("/dashboard/board");
  }

  return (
    <header
      style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "20px 32px", borderBottom: "1px solid var(--border)", flexWrap: "wrap", gap: 12,
      }}
    >
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>{title}</h1>
        {subtitle && <p style={{ margin: "2px 0 0", fontSize: 13, color: "var(--text-dim)" }}>{subtitle}</p>}
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span className="badge">{user.role === "board" ? "Board Member" : `${user.track} Track`}</span>

        <div
          title={user.name}
          style={{
            width: 34, height: 34, borderRadius: "50%",
            background: "var(--bg-elevated)", display: "grid", placeItems: "center",
            fontSize: 12, fontWeight: 700, color: "var(--royal-light)",
          }}
        >
          {user.name.split(" ").map((n) => n[0]).join("")}
        </div>

        {/* Dev-only preview switch — remove once real auth issues the role */}
        <button className="btn-ghost" onClick={handleSwitchRole}>
          Preview as {user.role === "board" ? "Member" : "Board"}
        </button>

        <button className="btn-ghost" onClick={handleLogout}>
          Log out
        </button>
      </div>

      <BoardPasswordModal
        open={showBoardGate}
        onSuccess={handleBoardUnlock}
        onCancel={() => setShowBoardGate(false)}
      />
    </header>
  );
}
