import { NavLink } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

// Every entry has a real "to" — this is what was missing before (the old
// Sidebar rendered <a href="#"> with no route, so nothing ever navigated).
const memberLinks = [
  { label: "Overview", icon: "🏠", to: "/dashboard/member", end: true },
  { label: "My Track", icon: "🧭", to: "/dashboard/member#track" },
  { label: "Submit Task", icon: "📤", to: "/dashboard/member/tasks" },
  { label: "Progress", icon: "📈", to: "/dashboard/member#progress" },
];

const boardLinks = [
  { label: "Overview", icon: "🏠", to: "/dashboard/board", end: true },
  { label: "Trainees", icon: "👥", to: "/dashboard/board#trainees" },
  { label: "Tracks", icon: "🧭", to: "/dashboard/board#tracks" },
  { label: "Evaluations", icon: "📋", to: "/dashboard/board/evaluations" },
];

export default function Sidebar() {
  const { user } = useAuth();
  const links = user?.role === "board" ? boardLinks : memberLinks;

  return (
    <aside
      style={{
        background: "var(--bg-panel)",
        borderRight: "1px solid var(--border)",
        padding: "24px 16px",
        display: "flex",
        flexDirection: "column",
        gap: 4,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 8px 24px" }}>
        <div
          style={{
            width: 36, height: 36, borderRadius: 10, display: "grid", placeItems: "center",
            background: "linear-gradient(135deg, var(--royal), var(--royal-light))",
            fontWeight: 700, fontSize: 11,
          }}
        >
          IEEE
        </div>
        <div style={{ fontWeight: 700, fontSize: 14 }}>Bootcamp Portal</div>
      </div>

      {links.map((l) => (
        <NavLink
          key={l.to}
          to={l.to}
          end={l.end}
          className={({ isActive }) => `sidebar-link${isActive ? " active" : ""}`}
        >
          <span>{l.icon}</span>
          <span>{l.label}</span>
        </NavLink>
      ))}
    </aside>
  );
}
