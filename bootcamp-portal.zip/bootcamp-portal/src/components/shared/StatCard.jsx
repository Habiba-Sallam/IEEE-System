export function StatCard({ label, value, trend, tone = "neutral" }) {
  const toneColor = {
    neutral: "var(--royal-light)",
    good: "var(--success)",
    warn: "var(--warning)",
    bad: "var(--danger)",
  }[tone];

  return (
    <div className="panel" style={{ padding: "18px 20px" }}>
      <div style={{ fontSize: 12, color: "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
        {label}
      </div>
      <div style={{ fontSize: 26, fontWeight: 700, marginTop: 6, color: toneColor }}>{value}</div>
      {trend && (
        <div style={{ fontSize: 12, color: "var(--text-dim)", marginTop: 4 }}>{trend}</div>
      )}
    </div>
  );
}

export function ChartCard({ title, subtitle, children }) {
  return (
    <div className="panel">
      <h3 className="panel-title">{title}</h3>
      {subtitle && <p className="panel-sub">{subtitle}</p>}
      {children}
    </div>
  );
}
