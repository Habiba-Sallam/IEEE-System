const FORM_URL = "https://forms.gle/YOUR_EVALUATION_REPORT_FORM_ID";

export default function EvaluationFormEmbed() {
  return (
    <div className="panel">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div>
          <h3 className="panel-title">📋 Evaluation / Report Form</h3>
          <p className="panel-sub">Log session evaluations and committee reports here</p>
        </div>
        <a href={FORM_URL} target="_blank" rel="noreferrer" className="btn-primary" style={{ textDecoration: "none" }}>
          Open in new tab ↗
        </a>
      </div>

      <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid var(--border)" }}>
        <iframe
          src={FORM_URL}
          title="Evaluation / Report Form"
          width="100%"
          height="480"
          style={{ border: "none", display: "block", background: "#fff" }}
          loading="lazy"
        />
      </div>
    </div>
  );
}
