import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ChartCard } from "../shared/StatCard";

export default function SubmissionRateLineChart({ data, title = "Overall Submission Rate", subtitle = "% of trainees submitting on time, by week" }) {
  // data: [{ week: "W1", rate: 78 }, ...]
  return (
    <ChartCard title={title} subtitle={subtitle}>
      <div style={{ height: 220 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 4, right: 12, left: -20, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="rgba(148,163,196,0.08)" />
            <XAxis dataKey="week" tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ background: "#1A2033", border: "1px solid rgba(148,163,196,0.2)", borderRadius: 8 }}
              itemStyle={{ color: "#E9ECF5" }}
              formatter={(v) => [`${v}%`, "Submission rate"]}
            />
            <Line
              type="monotone"
              dataKey="rate"
              stroke="#4361EE"
              strokeWidth={2.5}
              dot={{ r: 3, fill: "#4361EE", stroke: "#0B0F1A", strokeWidth: 2 }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </ChartCard>
  );
}
