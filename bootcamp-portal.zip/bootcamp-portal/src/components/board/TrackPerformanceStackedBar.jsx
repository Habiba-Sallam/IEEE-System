import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { ChartCard } from "../shared/StatCard";

const TRACK_COLORS = {
  Excellent: "#4361EE",
  Good: "#6C83F5",
  "At Risk": "#F87171",
};

export default function TrackPerformanceStackedBar({ data, title = "Performance by Track", subtitle = "Trainee count per performance band, per track" }) {
  // data: [{ track: "Web", Excellent: 12, Good: 6, "At Risk": 2 }, { track: "AI", ... }, ...]
  return (
    <ChartCard title={title} subtitle={subtitle}>
      <div style={{ height: 220 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 4, right: 12, left: -20, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="rgba(148,163,196,0.08)" />
            <XAxis dataKey="track" tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip
              cursor={{ fill: "rgba(67,97,238,0.06)" }}
              contentStyle={{ background: "#1A2033", border: "1px solid rgba(148,163,196,0.2)", borderRadius: 8 }}
              itemStyle={{ color: "#E9ECF5" }}
            />
            <Legend wrapperStyle={{ fontSize: 12, color: "#8C96B4" }} />
            <Bar dataKey="Excellent" stackId="a" fill={TRACK_COLORS.Excellent} radius={[0, 0, 0, 0]} />
            <Bar dataKey="Good" stackId="a" fill={TRACK_COLORS.Good} />
            <Bar dataKey="At Risk" stackId="a" fill={TRACK_COLORS["At Risk"]} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ChartCard>
  );
}
