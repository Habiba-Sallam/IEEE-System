const TRACKS = ["All", "Web", "AI", "Cyber", "RAS"];

export default function TrackFilterTabs({ active, onChange }) {
  return (
    <div
      role="tablist"
      aria-label="Filter by track"
      style={{ display: "flex", gap: 6, flexWrap: "wrap" }}
    >
      {TRACKS.map((track) => {
        const isActive = active === track;
        return (
          <button
            key={track}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(track)}
            style={{
              padding: "7px 16px",
              borderRadius: 20,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: "pointer",
              border: `1px solid ${isActive ? "var(--royal)" : "var(--border)"}`,
              background: isActive ? "var(--royal)" : "var(--bg-panel-2)",
              color: isActive ? "#fff" : "var(--text-dim)",
              transition: "all 0.15s",
            }}
          >
            {track}
          </button>
        );
      })}
    </div>
  );
}
