import { useMemo, useState } from "react";

export default function MembersOverviewTable({ members, subtitle }) {
  const [sortKey, setSortKey] = useState("score");
  const [query, setQuery] = useState("");

  const rows = useMemo(() => {
    return members
      .filter((m) => m.name.toLowerCase().includes(query.toLowerCase()))
      .sort((a, b) => b[sortKey] - a[sortKey]);
  }, [members, sortKey, query]);

  return (
    <div className="panel">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
        <div>
          <h3 className="panel-title">Trainees Overview</h3>
          <p className="panel-sub">{subtitle ?? `${members.length} trainees across 4 tracks`}</p>
        </div>
        <input
          placeholder="Search trainee…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{
            background: "var(--bg-panel-2)", border: "1px solid var(--border)", color: "var(--text)",
            padding: "8px 12px", borderRadius: 8, fontSize: 13,
          }}
        />
      </div>

      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--text-faint)", fontSize: 11.5, textTransform: "uppercase" }}>
              <th style={{ padding: "8px 10px" }}>Trainee</th>
              <th style={{ padding: "8px 10px" }}>Track</th>
              <Th label="Score" active={sortKey === "score"} onClick={() => setSortKey("score")} />
              <Th label="Attendance" active={sortKey === "attendance"} onClick={() => setSortKey("attendance")} />
              <th style={{ padding: "8px 10px" }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((m) => (
              <tr key={m.id} style={{ borderTop: "1px solid var(--border)" }}>
                <td style={{ padding: "10px" }}>{m.name}</td>
                <td style={{ padding: "10px", color: "var(--text-dim)" }}>{m.track}</td>
                <td style={{ padding: "10px", fontFamily: "monospace", fontWeight: 700 }}>{m.score}</td>
                <td style={{ padding: "10px", fontFamily: "monospace" }}>{m.attendance}%</td>
                <td style={{ padding: "10px" }}>
                  <StatusPill status={m.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({ label, active, onClick }) {
  return (
    <th
      onClick={onClick}
      style={{ padding: "8px 10px", cursor: "pointer", color: active ? "var(--royal-light)" : undefined }}
    >
      {label} {active && "↓"}
    </th>
  );
}

function StatusPill({ status }) {
  const styles = {
    Excellent: { bg: "var(--royal-dim)", color: "var(--royal-light)" },
    Good: { bg: "var(--success-dim)", color: "var(--success)" },
    "At Risk": { bg: "var(--danger-dim)", color: "var(--danger)" },
  }[status] || { bg: "var(--bg-panel-2)", color: "var(--text-dim)" };

  return (
    <span style={{ background: styles.bg, color: styles.color, padding: "3px 10px", borderRadius: 20, fontSize: 11.5, fontWeight: 600 }}>
      {status}
    </span>
  );
}
