import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { ChartCard } from "../shared/StatCard";

export default function ScoresBarChart({ scores }) {
  // scores: [{ task: "Task 1", score: 85 }, ...]
  return (
    <ChartCard title="Scores per Task" subtitle="Out of 100 points">
      <div style={{ height: 200 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={scores} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="rgba(148,163,196,0.08)" />
            <XAxis dataKey="task" tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: "#5B6480", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip
              cursor={{ fill: "rgba(67,97,238,0.08)" }}
              contentStyle={{ background: "#1A2033", border: "1px solid rgba(148,163,196,0.2)", borderRadius: 8 }}
              itemStyle={{ color: "#E9ECF5" }}
            />
            <Bar dataKey="score" radius={[6, 6, 0, 0]}>
              {scores.map((s, i) => (
                <Cell key={i} fill={s.score >= 70 ? "#4361EE" : s.score >= 50 ? "#FBBF24" : "#F87171"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ChartCard>
  );
}
