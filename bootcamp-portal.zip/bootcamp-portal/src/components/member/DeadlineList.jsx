function urgencyTone(daysLeft) {
  if (daysLeft <= 1) return "bad";
  if (daysLeft <= 3) return "warn";
  return "good";
}

export default function DeadlineList({ deadlines }) {
  return (
    <div className="panel">
      <h3 className="panel-title">Upcoming Deadlines</h3>
      <p className="panel-sub">Soonest first — don't let these slip</p>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {deadlines.map((d) => {
          const tone = urgencyTone(d.daysLeft);
          const toneColor = { good: "var(--success)", warn: "var(--warning)", bad: "var(--danger)" }[tone];
          return (
            <div
              key={d.id}
              style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "12px 14px", borderRadius: 12, background: "var(--bg-panel-2)",
                border: "1px solid var(--border)",
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: 13.5 }}>{d.title}</div>
                <div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>{d.track}</div>
              </div>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: toneColor }}>
                {d.daysLeft === 0 ? "Due today" : `${d.daysLeft}d left`}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
