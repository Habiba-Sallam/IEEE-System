/**
 * Highly-visible embedded form. Swap FORM_URL for your live Google Form /
 * Notion form / Tally embed URL. Keeping this as a straightforward iframe
 * (rather than reimplementing the form in React) means the source of truth
 * for form fields stays in one place — whatever tool your team already
 * uses to collect submissions.
 */
const FORM_URL = "https://forms.gle/YOUR_TASK_SUBMISSION_FORM_ID";

export default function SubmissionFormEmbed() {
  return (
    <div
      className="panel"
      style={{
        border: "1px solid rgba(67,97,238,0.35)",
        boxShadow: "0 0 0 1px rgba(67,97,238,0.08), 0 20px 50px -30px rgba(67,97,238,0.5)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div>
          <h3 className="panel-title">📤 Submit Your Task</h3>
          <p className="panel-sub">Don't wait until the deadline — submit as soon as you're ready</p>
        </div>
        <a href={FORM_URL} target="_blank" rel="noreferrer" className="btn-primary" style={{ textDecoration: "none" }}>
          Open in new tab ↗
        </a>
      </div>

      <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid var(--border)" }}>
        <iframe
          src={FORM_URL}
          title="Task Submission Form"
          width="100%"
          height="480"
          style={{ border: "none", display: "block", background: "#fff" }}
          loading="lazy"
        />
      </div>
    </div>
  );
}
