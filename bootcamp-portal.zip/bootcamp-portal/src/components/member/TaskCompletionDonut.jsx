import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { ChartCard } from "../shared/StatCard";

export default function TaskCompletionDonut({ completed, pending }) {
  const data = [
    { name: "Completed", value: completed, color: "var(--success)" },
    { name: "Pending", value: pending, color: "var(--warning)" },
  ];
  const total = completed + pending || 1;
  const pct = Math.round((completed / total) * 100);

  return (
    <ChartCard title="Tasks Completed vs. Pending" subtitle="Your progress this bootcamp">
      <div style={{ position: "relative", height: 200 }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              innerRadius={62}
              outerRadius={86}
              paddingAngle={3}
              stroke="none"
            >
              {data.map((d, i) => (
                <Cell key={i} fill={d.color === "var(--success)" ? "#34D399" : "#FBBF24"} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{ background: "#1A2033", border: "1px solid rgba(148,163,196,0.2)", borderRadius: 8 }}
              itemStyle={{ color: "#E9ECF5" }}
            />
          </PieChart>
        </ResponsiveContainer>
        <div
          style={{
            position: "absolute", inset: 0, display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center", pointerEvents: "none",
          }}
        >
          <span style={{ fontSize: 24, fontWeight: 700, color: "#34D399" }}>{pct}%</span>
          <span style={{ fontSize: 11, color: "var(--text-faint)" }}>done</span>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "center", gap: 18, marginTop: 10 }}>
        <Legend color="#34D399" label={`Completed (${completed})`} />
        <Legend color="#FBBF24" label={`Pending (${pending})`} />
      </div>
    </ChartCard>
  );
}

function Legend({ color, label }) {
  return (
    <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--text-dim)" }}>
      <span style={{ width: 9, height: 9, borderRadius: 3, background: color }} />
      {label}
    </span>
  );
}
