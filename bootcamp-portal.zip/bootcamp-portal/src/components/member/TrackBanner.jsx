export default function TrackBanner({ track, streak, nextMilestone, onViewRoadmap }) {
  return (
    <div
      className="panel"
      style={{
        background: "linear-gradient(135deg, var(--royal-dim), var(--bg-panel) 60%)",
        border: "1px solid rgba(67,97,238,0.3)",
        display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16,
      }}
    >
      <div>
        <span className="badge">{track} Track</span>
        <h2 style={{ margin: "10px 0 4px", fontSize: 22, fontWeight: 700 }}>
          🔥 {streak}-day streak — keep it going!
        </h2>
        <p style={{ margin: 0, color: "var(--text-dim)", fontSize: 13.5 }}>
          Next milestone: {nextMilestone}
        </p>
      </div>
      <button className="btn-primary" onClick={onViewRoadmap}>View Roadmap</button>
    </div>
  );
}
