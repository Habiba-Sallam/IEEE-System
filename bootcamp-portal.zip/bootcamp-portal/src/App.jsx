import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import ProtectedRoute from "./routes/ProtectedRoute";
import Login from "./pages/Login";
import MemberDashboard from "./pages/MemberDashboard";
import TaskSubmissionPage from "./pages/TaskSubmissionPage";
import BoardDashboard from "./pages/BoardDashboard";
import EvaluationsPage from "./pages/EvaluationsPage";
import NotFound from "./pages/NotFound";
import "./styles/theme.css";

// Sends a logged-in user to their own dashboard, or to /login if signed out.
function RoleRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={user.role === "board" ? "/dashboard/board" : "/dashboard/member"} replace />;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<RoleRedirect />} />
      <Route path="/login" element={<Login />} />

      {/* Member-only pages */}
      <Route
        path="/dashboard/member"
        element={
          <ProtectedRoute allow={["member"]}>
            <MemberDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/member/tasks"
        element={
          <ProtectedRoute allow={["member"]}>
            <TaskSubmissionPage />
          </ProtectedRoute>
        }
      />

      {/* Board-only pages */}
      <Route
        path="/dashboard/board"
        element={
          <ProtectedRoute allow={["board"]}>
            <BoardDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/board/evaluations"
        element={
          <ProtectedRoute allow={["board"]}>
            <EvaluationsPage />
          </ProtectedRoute>
        }
      />

      {/* Unknown routes never render a blank screen */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
