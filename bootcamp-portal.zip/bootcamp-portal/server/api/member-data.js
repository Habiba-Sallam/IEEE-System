/**
 * Example serverless function (Vercel/Netlify-style handler — adapt the
 * request/response shape to your host). This is the ONLY place that ever
 * reads process.env.NOTION_API_KEY.
 *
 * Flow:
 *   1. Resolve the caller's identity from their session cookie (never from
 *      a client-supplied ID) — swap `getSessionUser` for your real auth check.
 *   2. Query Notion filtered to that member's row(s) only.
 *   3. Shape + return just what the Member Dashboard needs.
 */

import { Client } from "@notionhq/client";

const notion = new Client({ auth: process.env.NOTION_API_KEY });
const MEMBERS_DB_ID = process.env.NOTION_MEMBERS_DB_ID;

export default async function handler(req, res) {
  const sessionUser = await getSessionUser(req); // { id, notionMemberId, role }
  if (!sessionUser) return res.status(401).json({ error: "Not authenticated" });

  try {
    const response = await notion.databases.query({
      database_id: MEMBERS_DB_ID,
      filter: {
        property: "Member ID",
        rich_text: { equals: sessionUser.notionMemberId },
      },
    });

    if (!response.results.length) {
      return res.status(404).json({ error: "No record found for this member" });
    }

    const page = response.results[0];
    const p = page.properties;

    res.setHeader("Cache-Control", "private, max-age=30");
    return res.status(200).json({
      track: p["Track"]?.select?.name ?? "",
      streak: p["Streak"]?.number ?? 0,
      nextMilestone: p["Next Milestone"]?.rich_text?.[0]?.plain_text ?? "",
      deadlines: (p["Upcoming Deadlines"]?.rich_text?.[0]?.plain_text
        ? JSON.parse(p["Upcoming Deadlines"].rich_text[0].plain_text)
        : []),
      tasksCompleted: p["Tasks Completed"]?.number ?? 0,
      tasksPending: p["Tasks Pending"]?.number ?? 0,
      scores: (p["Scores JSON"]?.rich_text?.[0]?.plain_text
        ? JSON.parse(p["Scores JSON"].rich_text[0].plain_text)
        : []),
    });
  } catch (err) {
    console.error("[member-data] Notion query failed:", err);
    // Never forward the raw Notion error body to the client — it can leak schema details.
    return res.status(502).json({ error: "Could not load your data right now." });
  }
}

async function getSessionUser(req) {
  // Replace with real session verification (JWT cookie, NextAuth, etc.)
  const sessionToken = req.cookies?.session;
  if (!sessionToken) return null;
  // ... look up sessionToken in your session store / verify JWT ...
  return { id: "abc123", notionMemberId: "member_123", role: "member" };
}
