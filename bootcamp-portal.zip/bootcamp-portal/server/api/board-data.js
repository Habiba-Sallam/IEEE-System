/**
 * Board endpoint — requires an admin/board role claim on the session.
 * Pulls all member rows once, aggregates server-side, and returns only the
 * pre-shaped data the charts/table need (not a raw dump of every property).
 */

import { Client } from "@notionhq/client";

const notion = new Client({ auth: process.env.NOTION_API_KEY });
const MEMBERS_DB_ID = process.env.NOTION_MEMBERS_DB_ID;
const SUBMISSIONS_LOG_DB_ID = process.env.NOTION_SUBMISSIONS_LOG_DB_ID; // one row per submission event

export default async function handler(req, res) {
  const sessionUser = await getSessionUser(req);
  if (!sessionUser) return res.status(401).json({ error: "Not authenticated" });
  if (sessionUser.role !== "board") return res.status(403).json({ error: "Forbidden" });

  try {
    const members = await fetchAllPages(MEMBERS_DB_ID);
    const parsed = members.map(parseMember);

    const totalTrainees = parsed.length;
    const avgScore = Math.round(parsed.reduce((s, m) => s + m.score, 0) / (totalTrainees || 1));
    const submissionRate = Math.round(
      (parsed.filter((m) => m.status !== "At Risk").length / (totalTrainees || 1)) * 100
    );
    const atRisk = parsed.filter((m) => m.status === "At Risk").length;

    const trackPerformance = groupByTrack(parsed);
    const submissionTrend = await buildSubmissionTrend();

    res.setHeader("Cache-Control", "private, max-age=60");
    return res.status(200).json({
      totalTrainees,
      avgScore,
      submissionRate,
      atRisk,
      trackPerformance,
      submissionTrend,
      members: parsed, // only send the fields the table actually renders (already trimmed in parseMember)
    });
  } catch (err) {
    console.error("[board-data] Notion query failed:", err);
    return res.status(502).json({ error: "Could not load board data right now." });
  }
}

async function fetchAllPages(databaseId) {
  let results = [];
  let cursor;
  do {
    const page = await notion.databases.query({
      database_id: databaseId,
      ...(cursor ? { start_cursor: cursor } : {}),
    });
    results = results.concat(page.results);
    cursor = page.has_more ? page.next_cursor : undefined;
  } while (cursor);
  return results;
}

function parseMember(page) {
  const p = page.properties;
  return {
    id: page.id,
    name: p["Name"]?.title?.[0]?.plain_text ?? "Unnamed",
    track: p["Track"]?.select?.name ?? "Unknown",
    score: p["Total Score"]?.number ?? 0,
    attendance: p["Attendance %"]?.number ?? 0,
    status: p["Status"]?.select?.name ?? "Good",
  };
}

function groupByTrack(members) {
  const tracks = ["Web", "AI", "Cyber", "RAS"];
  return tracks.map((track) => {
    const inTrack = members.filter((m) => m.track === track);
    return {
      track,
      Excellent: inTrack.filter((m) => m.status === "Excellent").length,
      Good: inTrack.filter((m) => m.status === "Good").length,
      "At Risk": inTrack.filter((m) => m.status === "At Risk").length,
    };
  });
}

// Historical time series should come from a lightweight log/snapshot rather
// than a live Notion aggregation on every request — see README §3.
async function buildSubmissionTrend() {
  if (!SUBMISSIONS_LOG_DB_ID) {
    return []; // wire up your snapshot store here
  }
  const rows = await fetchAllPages(SUBMISSIONS_LOG_DB_ID);
  return rows.map((r) => ({
    week: r.properties["Week"]?.title?.[0]?.plain_text ?? "",
    rate: r.properties["Rate"]?.number ?? 0,
  }));
}

async function getSessionUser(req) {
  const sessionToken = req.cookies?.session;
  if (!sessionToken) return null;
  return { id: "admin_1", role: "board" };
}
