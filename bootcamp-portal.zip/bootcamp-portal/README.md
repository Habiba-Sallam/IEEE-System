# IEEE Bootcamp Management Portal — Role-Based Dashboards

## 1. Folder structure

```
bootcamp-portal/
├── server/                          # Server-side only — holds the Notion token
│   └── api/
│       ├── member-data.js           # GET /api/member-data?memberId=... (scoped query)
│       └── board-data.js            # GET /api/board-data (aggregated query)
│
└── src/
    ├── main.jsx                     # App entry
    ├── App.jsx                      # Router + role gate
    ├── context/
    │   └── AuthContext.jsx          # Holds logged-in user + role ("member" | "board")
    ├── routes/
    │   └── ProtectedRoute.jsx       # Redirects if role doesn't match the route
    ├── services/
    │   └── api.js                   # Frontend fetch wrappers — talk to OUR server, never Notion directly
    ├── styles/
    │   └── theme.css                # Design tokens: charcoal/midnight navy + royal blue
    ├── components/
    │   ├── shared/
    │   │   ├── Sidebar.jsx
    │   │   ├── Topbar.jsx
    │   │   ├── StatCard.jsx
    │   │   └── ChartCard.jsx
    │   ├── member/
    │   │   ├── TrackBanner.jsx
    │   │   ├── DeadlineList.jsx
    │   │   ├── TaskCompletionDonut.jsx
    │   │   ├── ScoresBarChart.jsx
    │   │   └── SubmissionFormEmbed.jsx
    │   └── board/
    │       ├── MembersOverviewTable.jsx
    │       ├── SubmissionRateLineChart.jsx
    │       ├── TrackPerformanceStackedBar.jsx
    │       └── EvaluationFormEmbed.jsx
    └── pages/
        ├── MemberDashboard.jsx      # Isolated route: /dashboard/member
        └── BoardDashboard.jsx       # Isolated route: /dashboard/board
```

**Why two isolated pages instead of one dashboard with an `if (role)` branch inside it:**
the two audiences want fundamentally different information density (one card's worth of
"my stuff" vs. a bird's-eye table of 14 teams), so isolating them at the route level keeps
each component tree simple, keeps bundle-splitting easy (`React.lazy`), and means a CSS
change for one view can never accidentally leak into the other.

## 2. Wireframe logic

**Member Dashboard** — vertical priority: motivation → obligation → proof of work
```
┌─────────────────────────────────────────────────────────┐
│ Topbar: avatar · name · track badge · logout             │
├───────────┬─────────────────────────────────────────────┤
│           │  Track Banner (current track + streak)       │
│  Sidebar  ├─────────────────────────────────────────────┤
│  (nav)    │  Upcoming Deadlines (list, soonest first)    │
│           ├───────────────────┬─────────────────────────┤
│           │ Tasks Donut        │ Scores Bar (per task)  │
│           ├───────────────────┴─────────────────────────┤
│           │  ⭐ Task Submission Form (embedded, prominent)│
└───────────┴─────────────────────────────────────────────┘
```

**Board Dashboard** — vertical priority: fleet health → drill-down → action
```
┌─────────────────────────────────────────────────────────┐
│ Topbar: admin name · role badge · logout                 │
├───────────┬─────────────────────────────────────────────┤
│           │  Stat strip: total trainees · avg score ·    │
│  Sidebar  │  submission rate · at-risk count              │
│  (nav)    ├───────────────────┬─────────────────────────┤
│           │ Submission Rate    │ Performance by Track    │
│           │ (line, over time)  │ (stacked bar, 4 tracks) │
│           ├───────────────────┴─────────────────────────┤
│           │  Members Overview Table (sortable, filter)   │
│           ├─────────────────────────────────────────────┤
│           │  📋 Evaluation / Report Form (embedded)       │
└───────────┴─────────────────────────────────────────────┘
```

## 3. Notion integration — validation & best practices

**Never call `api.notion.com` from the browser.** The Notion API has no CORS allowance and,
more importantly, the integration secret is bearer-token auth with no per-request scoping —
if it ships in client JS, anyone can read your entire workspace with it. Every dashboard in
this project calls **our own backend** (`/api/member-data`, `/api/board-data`), which is the
only thing that ever holds `NOTION_API_KEY`.

### Member view — scoped, least-privilege
- The frontend sends the logged-in user's session token, **not their Notion row ID**, to
  `/api/member-data`.
- The server resolves session → member ID (from your auth provider / a lookup table), then
  builds the Notion query filter server-side:
  ```js
  filter: { property: "Member ID", rich_text: { equals: resolvedMemberId } }
  ```
  The client can never pass an arbitrary `memberId` and pull someone else's data — the ID is
  derived from the authenticated session, not from request input.
- Cache per-member responses briefly (30–60s) to avoid hammering Notion's rate limit
  (~3 requests/second) if the dashboard polls.

### Board view — aggregated, admin-gated
- `/api/board-data` requires the session to carry an admin/board role claim; reject with 403
  otherwise. Check this **on the server**, not just by hiding the route in the React router
  (client-side route guards are UX, not security).
- Pull all rows once, aggregate server-side (sums, per-track grouping, time-bucketed
  submission rate), and return only the pre-aggregated shape the charts need — don't ship
  raw per-member rows to the board view unless the table genuinely needs every field.
- For the line chart's "over time" data, either maintain a small `Submissions Log` database
  in Notion (one row per submission event, easy to bucket by day/week) or snapshot daily
  aggregates into a lightweight store (KV, Postgres) via a scheduled job — querying Notion
  live for a historical time series on every page load is slow and rate-limit-risky.

### General
- Set `Cache-Control` headers on your API routes and/or use SWR/React Query on the frontend
  (`staleTime`) so charts don't refetch on every re-render.
- Validate/whitelist the `database_id` server-side; never accept it from the client.
- Log Notion 4xx/5xx responses server-side and return a generic error to the client — don't
  forward raw Notion error bodies (they can include schema details).
- Rotate the integration secret if it's ever been in a client bundle, a public repo, or a
  screenshot.
